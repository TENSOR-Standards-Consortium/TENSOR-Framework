# TENSOR Framework

TENSOR is being developed as a public standard for **all cyber investigations**, with one shared investigative layer for humans and agents. Public domain profiles, vendor integrations, and business policies build on that layer without silently changing its meaning.

The project preserves its existing question graphs and introduces a **Core investigation-record candidate, `0.1.0-draft.1`**, for public review. The candidate connects questions, evidence references, observations, assessments, decisions, and revisions in a portable record. It is not a ratified standard or a certification program.

## Public event profiles

[Sixteen draft event profiles](drafts/core/event-profiles/README.md) add credential/workload state, host/network/cloud state, cloud data access, mailbox and collaboration activity, autonomous application actions, file deletion and historical lineage across all seven domains. Their explicitly qualified definitions and 144 authored route scenarios sit above the unchanged working graph and schema. These are author-tested drafts; institutional review and independent exchange remain open.

## Start here

- **Investigators:** read the [founding charter](proposals/founding-core-v0.1.0/00-charter.md) and [two synthetic cases](core/v0.1.0-draft.1/examples/README.md).
- **Implementers:** use the [candidate binding and API](core/v0.1.0-draft.1/README.md), [schemas](core/v0.1.0-draft.1/schemas/), and [check coverage](core/v0.1.0-draft.1/coverage.md).
- **Reviewers:** use the [review packet](docs/reviewer-packet.md), [38 proposed requirements](proposals/founding-core-v0.1.0/01-core-contract.md), and [standards crosswalk](proposals/founding-core-v0.1.0/03-standards-crosswalk.md).
- **Contributors:** see [CONTRIBUTING](CONTRIBUTING.md), [governance status](GOVERNANCE.md), and the [90-day adoption work plan](docs/adoption-plan.md).
- **Everyone exploring, implementing or reviewing TENSOR:** use the [current public dataset](dataset/current.json) and [current review package](review/current/README.md). The graph, profiles, Lab reference cases and review archive use these same exact artifacts. See [accepted bootstrap stewardship](docs/stewardship.md) and the [next-stage plan](docs/next-stage-plan.md). Earlier releases and review snapshots are historical archives.

The [public website](https://tensor-standards.pages.dev) is live in the dedicated TENSOR Cloudflare account, with automatic publication from the website repository's `main` branch. This repository holds specification source and immutable graph releases. A branch or a passing local test is not proof that a later change has been deployed.

## Run the candidate

Use Node.js 24 LTS (see `.node-version`). From this checkout:

```sh
npm ci
npm run check
node core/v0.1.0-draft.1/cli.mjs core/v0.1.0-draft.1/examples/case-a.bundle.json
node core/v0.1.0-draft.1/cli.mjs core/v0.1.0-draft.1/examples/case-b.bundle.json
```

The CLI emits a scoped JSON report: exit `0` means its bounded checks passed, `1` means failure, `2` means indeterminate interpretation, and `64` means an input or usage error. Reports retain `notRun` checks. They cannot establish evidence truth, actual authorization, safety, or the quality of an investigation. Importing a record does not authorize actions.

The runtime is usable in Node and browsers without third-party runtime dependencies or network retrieval. This package is private in npm: the commands above use the repository, not a published registry package.

## Two tracks, explicit identities

| Track | Current artifacts | Meaning |
| --- | --- | --- |
| Existing graph releases | Stable graph/schema `0.20260206e`; 588 questions and 1,554 edges | Reusable investigative question definitions under their original release contract |
| Existing graph drafts | `0.20261012b`; 609 questions and 1,554 edges, unchanged schema `0.20260206e` | [Seven-domain agent challenge review](drafts/core/reviews/2026-10-12-independent-review/README.md); 105 graph tests and 1,791 existing scenarios; external domain review and additional event profiles remain open |
| Founding proposal | `proposals/founding-core-v0.1.0/`; proposal `0.1.0` | Public purpose, logical contract, and proposed governance |
| Core implementation candidate | `core/v0.1.0-draft.1/`; binding `0.1.0-draft.1` | Trial JSON representation, validator, CLI, schemas, and synthetic records |

The graph release numbering convention (`MAJOR.YYYYMMDD[letter]`) remains intact. The candidate binding uses its own explicit draft identifier. Neither implies an upgrade of the other. Published `releases/` bytes are preserved, and a legacy graph does not become an investigation record by relabeling it.

Legacy identifiers such as `Q12` are meaningful only with their source graph version and digest. Use the [migration inventory procedure](docs/legacy-migration.md) before reusing them in a candidate definition. Migration must not invent criteria, evidence, actors, or decisions.

## Repository map

| Path | Purpose |
| --- | --- |
| `core/v0.1.0-draft.1/` | Executable candidate binding, schemas, examples, CLI, and check boundaries |
| `proposals/founding-core-v0.1.0/` | Founding text; proposed requirements TC-01 through TC-38 |
| `drafts/core/source/` | Editable legacy graph questions, edges, and entry nodes |
| `drafts/extensions/`, `drafts/vendors/`, `drafts/orgs/` | Existing extension and overlay authoring tracks |
| `releases/` | Existing immutable snapshots, release catalog, and checksums |
| `standards/` | Existing graph compatibility and authoring policies |
| `tests/`, `scripts/` | Candidate checks and legacy preservation tooling |
| `docs/` | Candidate design decision, reviewer packet, migration, and release preparation |

The Core boundary remains vendor-neutral. A business policy or vendor tool may supply context and perform authorized work; it cannot turn `unknown` into `no`, suppress conflicting assessments, or replace Core semantics under the same identity. Public profiles must remain usable without buying a vendor product.

## Legacy graph checks

Use Python 3 from the repository root:

```sh
python3 scripts/validate_release_contract.py
python3 -m unittest discover -s tests/legacy -v
python3 scripts/evaluate_entry_scenarios.py
python3 scripts/lint_core_graph_quality.py --graph-path drafts/core/tensor.core.graph.json --entry-path drafts/core/source/entry_nodes.json --output-dir /tmp/tensor-draft-quality
```

The linter applies [graph assurance policy `tensor-graph-assurance/3`](standards/graph-assurance-policy.md): structural validity, exact evidence cards, safe transitions and scenario agreement/coverage block acceptance. Historical topology scores remain visible diagnostics, with unchanged formulas and thresholds. The canonical draft selects its adjacent evidence package automatically; other artifacts need explicit criteria/scenario paths. `--draft-review` remains a compatibility spelling with the same checks. Reports pin graph, evidence and policy implementation digests and write outside `releases/`. Acceptance does not authorize publication or rewrite historical reports. See the [gate review and counterexamples](drafts/core/reviews/2026-10-11-topology-policy/README.md).

## Public participation and claims

AI security teams governing agents and autonomous systems are the first adoption audience. The contract must also work for conventional identity, cloud, endpoint, network, application, email, and file investigations conducted by humans or mixed teams.

The next gate is reproducible review and exchange by independent implementations, with disclosed losses and limitations. No institutional recognition, partnership, independent council, or stable Core approval is claimed. See the [release checklist](docs/release-checklist.md) for evidence required at each stage.

The existing [Apache License 2.0](LICENSE) remains unchanged. Proposed governance does not create a new legal entity, appoint stewards, or impose additional patent or contributor terms. Citations should identify the exact commit and candidate version; [CITATION.cff](CITATION.cff) supplies project metadata.

## Current dataset publication

The canonical active inventory is `dataset/current.json`. It pins one graph, evidence criteria, profiles, schemas and reference records. The website synchronizes these bytes; historical releases remain separate archives.

After editing source, regenerate the dataset with `node scripts/build_dataset.mjs`, run the checks, update the observed `review/templates/validation.json` record, and commit the source. Build `python3 scripts/build_current_review.py` from that committed source, verify with `python3 scripts/build_current_review.py --check`, then commit the generated package. The archive excludes its own `review/current` output directory to avoid recursion. CI rejects source drift or a different packaged dataset. Synchronize the website from the resulting clean Framework commit.
