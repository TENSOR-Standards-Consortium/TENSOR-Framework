# First-hour technical review

Review the current public dataset at source **6ef89080b4dc765f2cf89e63500f2b84b29ac22b**, graph **0.20261016a**, dataset **urn:tensor:dataset:sha256:277f00e04a84493396c86090fde2c7e0056f2ae7847e7a9ea7bb6a7445d79cda**.

1. Read the charter and logical contract in `proposals/founding-core-v0.1.0/`, then the binding and coverage notes in `core/v0.1.0-draft.1/`.
2. Open the website's five-minute introduction and follow the SOC sign-in case into the graph and Lab. Check how human and agent assessments, vendor evidence mappings and company policy remain distinct. Repeat with workload/cloud/network and attachment/host/tool cases.
3. Use `dataset.json` to identify the exact current graph, criteria, event profiles and example records. Challenge yes, no and unknown criteria; multiple routes per answer; independently bound cross-domain leads; and retained parallel findings.
4. Inspect `drafts/core/reviews/2026-10-16-contextual-routing/` for all 602 shared-destination dispositions and the current answer/context repair. The 13 October AI review pins the archived baseline, not this repair. Neither is institutional approval. Follow `parallel-followup` through both branches and the later identity context; confirm negative, unknown and historical answers remain separate.
5. Export and reimport a reference case. Independently implement an exchange direction where possible; disclose shared code, omissions, unsupported meaning and losses. CASE/UCO reuse and loss analysis remain open review questions.
6. Return one bounded finding using `review-form.md`: exact dataset, question/profile/requirement, minimal reproduction, observed and expected behavior, and untested scope. Preserve disagreement after maintainer disposition.

The reference cases use fictional observations. No graph position, route, validator result or actor type authenticates evidence, supplies a finding or grants authority.
